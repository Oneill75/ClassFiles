<pre>
<?php
require_once './php/classes/class.database.php';

echo "\n";
echo "\n";


$db = new Databaseconnection('fi321', 'root', '');
$result = $db->selectTableData('user', '*', '');
var_dump($result);
echo "\n";
echo "\n";


$result = $db->selectTableData('user', 'username, email', '');
var_dump($result);
echo "\n";
echo "\n";


$result = $db->selectTableData('user', 'username, role', ' where role=\'Admin\'');
var_dump($result);
echo "\n";
echo "\n";

$result = $db->insertTableData('user', "('10000', 'elli', '123435', 'elli@elli.com', '0', 'Member')");
var_dump($result);
echo "\n";
echo "\n";


$db = null;
?>
</pre>