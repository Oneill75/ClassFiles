<?php
class Databaseconnection {
	
	private $connection;
	private $dbhost = 'localhost';
	
	public function __construct($dbname, $uname, $pwd) {
		try {
			$this->connection = new PDO("mysql:host=$this->dbhost;dbname=$dbname;", $uname, $pwd);
			$this->connection->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
		} catch (Exception $e) {
			throw new Exception($e->getMessage());
		}
		
	}
	public function createTable() {
		
	}
	
	public function insertTableData($tablename, $values ) {
		$sql = 'INSERT ' . $tablename . ' VALUES ' . $values;
		$stmt = $this->connection->prepare($sql);
		$stmt->execute();
		// $this->connection = null;
		return $stmt;
		
		
		
	}
	
	public function updateTableData() {
		
	}
	
	public function deleteTableData() {
		
	}

	public function selectTableData($tablename, $columns, $options) {
		$sql = 'SELECT ' . $columns . ' FROM ' . $tablename . $options;
		$stmt = $this->connection->prepare($sql);
		$stmt->execute();
		// $this->connection = null;
		return $stmt->fetchAll();
	}

}