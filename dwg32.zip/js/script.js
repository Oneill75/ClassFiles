'use strict';

let url = 'php/response.php';
let loginform = document.getElementById('loginform');

loginform.addEventListener('submit', (ev) => {
	ev.preventDefault();
	queryDatabase();
});

function queryDatabase() {
	
	let formData = new FormData(loginform);
	
	fetch(url, {
		method: 'POST',
		body: formData,
	}).then(response => {
		if (response.ok) console.log(response.json());
	});
}
