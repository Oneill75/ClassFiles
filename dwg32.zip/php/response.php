<?php
$dataForJSON = ['response' => 'ok'];
echo json_encode($dataForJSON);
